import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class sqservlet extends HttpServlet 
{

		public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
		{
			int k=Integer.parseInt(req.getParameter("k"));
			PrintWriter out=res.getWriter();
			out.println("square of the result in 1st servlet is "+k*k);
		}
}
