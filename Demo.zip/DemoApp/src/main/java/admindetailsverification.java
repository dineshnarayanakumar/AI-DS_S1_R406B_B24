import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/admindetailsver")
public class admindetailsverification  extends HttpServlet 
{
	

	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		int id=Integer.parseInt(req.getParameter("id"));
		String email= (String)req.getParameter("email");
		String password=(String)req.getParameter("pswd");
		PrintWriter out=res.getWriter();
//		out.println(id);
//		out.println(email);
//		out.println(password);
		try {
		    Driver dob=new oracle.jdbc.driver.OracleDriver();
		    DriverManager.registerDriver(dob);
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","reddysmvsv");
		    PreparedStatement pstmt=con.prepareStatement("select * from admindetails where id=?");
		    
		    pstmt.setInt(1, id);

			ResultSet rs=pstmt.executeQuery();

			//System.out.println(rs.getRow());
			// by default it will point at 0th location, rows will start at 1st loc
			String mail="";
			String pass="";
				
			while(rs.next()) //return type is T/False
			{
				mail=(String)rs.getString("email");
				pass=(String)rs.getString("password");
			}
			
			
			if(stringCompare(mail,email)==0 && stringCompare(pass,password)==0)
			{
				RequestDispatcher rd =req.getRequestDispatcher("questions.html");
				rd.forward(req, res);
			}
			else
			{
				out.println("YOU WERE NOT THE ADMIN");
			}
		    con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	
	public static int stringCompare(String str1, String str2)
    {
  
        int l1 = str1.length();
        int l2 = str2.length();
        int lmin = Math.min(l1, l2);
  
        for (int i = 0; i < lmin; i++) {
            int str1_ch = (int)str1.charAt(i);
            int str2_ch = (int)str2.charAt(i);
  
            if (str1_ch != str2_ch) {
                return str1_ch - str2_ch;
            }
        }
  
        // Edge case for strings like
        // String 1="Geeks" and String 2="Geeksforgeeks"
        if (l1 != l2) {
            return l1 - l2;
        }
  
        // If none of the above conditions is true,
        // it implies both the strings are equal
        else {
            return 0;
        }
    }
}