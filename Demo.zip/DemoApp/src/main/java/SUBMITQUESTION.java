import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/submiting")
public class SUBMITQUESTION  extends HttpServlet 
{
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
//		out.println("rama");
//		String t1 = (req.getParameter("1"));
//		String t2 = (req.getParameter("2"));
//		String t3 = (req.getParameter("3"));
//		String t4 = (req.getParameter("4"));
//		out.println(t1);
//		out.println(t2);
//		out.println(t3);
//		out.println(t4);
		out.println("Thank You !!");
	}
}