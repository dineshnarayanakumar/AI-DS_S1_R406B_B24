import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.*;

@WebServlet("/add")
public class addservlet extends HttpServlet 
{
	
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException
	{
//		int i = Integer.parseInt(req.getParameter("num1"));
//		int j = Integer.parseInt(req.getParameter("num2"));
////		int k=i+j;
		
		PrintWriter out=res.getWriter();
//		out.println("Result is "+k);
		try {
		    Driver dob=new oracle.jdbc.driver.OracleDriver();
		    DriverManager.registerDriver(dob);
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","reddysmvsv");
		    if(con!=null)
		    {
		      System.out.println("DB Connected");
		    }
		    else
		    {
		      System.out.println("DB Not Connected");
		    }
		    con.close();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}	
}













































//we can call the another servlet from this servlet by using request dispatcher
//RequestDispatcher rd =req.getRequestDispatcher("sq");
//rd.forward(req, res);

//we can pass the data to the other servlet by keeping the data in the request obj
//req.setAttribute("k",k);
//
//RequestDispatcher rd =req.getRequestDispatcher("sq");
//rd.forward(req, res);

//in another way also we can call the a servlet for one servlet to another servlet they are redirect
//sending data also here onlyby adding ? mark like a url in get method the data is directly kept in url
//res.sendRedirect("sq?k="+k); // URL REWRITING

//we can also send data from one servlet to another servlet using section and cokkies

