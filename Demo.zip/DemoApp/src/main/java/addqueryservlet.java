import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/addquery")
public class addqueryservlet  extends HttpServlet 
{
	public void service(HttpServletRequest req, HttpServletResponse res) throws IOException
	{
		PrintWriter out=res.getWriter();
		int qid=Integer.parseInt(req.getParameter("qid"));
		String query=req.getParameter("query");
		String opt1=req.getParameter("opt1");
		String opt2=req.getParameter("opt2");
		String opt3=req.getParameter("opt3");
		String opt4=req.getParameter("opt4");
		
		try {
		    Driver dob=new oracle.jdbc.driver.OracleDriver();
		    DriverManager.registerDriver(dob);
		    Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","reddysmvsv");
		    PreparedStatement pstmt=con.prepareStatement("insert into questions values(?,?,?,?,?,?)");
		    pstmt.setInt(1, qid);
		    pstmt.setString(2, query);
		    pstmt.setString(3, opt1);
		    pstmt.setString(4, opt2);
		    pstmt.setString(5, opt3);
		    pstmt.setString(6, opt4);
		    
		    int temp=pstmt.executeUpdate();
		    RequestDispatcher rd =req.getRequestDispatcher("questions.html");
			rd.forward(req, res);
		    con.close();
		}
		catch(Exception e)
		{
			out.println(e);
		}
		
	}
}